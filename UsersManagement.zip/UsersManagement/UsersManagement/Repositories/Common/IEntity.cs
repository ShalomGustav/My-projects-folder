﻿namespace UsersManagement.Repositories.Common;

public interface IEntity
{
    string Id { get; set; }
}
