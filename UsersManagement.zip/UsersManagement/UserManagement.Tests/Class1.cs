﻿namespace UserManagement.Tests
{
    public class Class1
    {

    }
}
